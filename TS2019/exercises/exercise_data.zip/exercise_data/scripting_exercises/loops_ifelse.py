# loops_ifelse.py
# script to demonstrate how to use loops and if/else statements in Python
# April 4, 2019
# Alissa Williams

greetings = ["hello", "hola", "bonjour", "hallo"] #initialize a list

for word in greetings:
	print(word)
	

	


