# Script for renaming .txt files to .fas files
# Alissa Williams
# April 9, 2019

for file in *.txt; do mv "$file" "${file%.txt}.fas" ; done
for file in *.fas ; do einsi $file > aligned_$file ; done