#!/usr/bin/perl

use strict;
use warnings;
use Bio::SearchIO;

my $usage = "\nUSAGE: $0 fasta_file blast_file color_file minLength minCoverage kmer\n\n";

my $fastaFile = shift or die($usage);
my $blastFile = shift or die($usage);
my $colorFile = shift or die($usage);
my $min_len = shift or die ($usage);
my $min_cov = shift or die ($usage);
my $kmer = shift or die ($usage);

my %colors;

my $FHC = open_file($colorFile);

while (<$FHC>){
	chomp $_;
	my @sl = split (/\t/, $_);
	$colors{$sl[0]} = $sl[1];
}

my %blastHash;

my $SearchIO_obj = new Bio::SearchIO(-format => 'blast', -file   => $blastFile);

while( my $result_obj = $SearchIO_obj->next_result ) {
	if ( my $hit_obj = $result_obj->next_hit ) {
		$blastHash{$result_obj->query_name}=$hit_obj->name; 
	}else{
		$blastHash{$result_obj->query_name}="None" 
	}
}

my $FH = open_file($fastaFile);

my $keep = 0;
my $cov;
my $seq;
my $len;
my $name;

print "Contig_name\tLength\tGC_content\tCoverage\tBLAST\tColor\n";

while (<$FH>){
	if (substr($_,0,1) eq '>'){
		if ($keep){
			my $A = () = $seq =~ /A/g;
			my $C = () = $seq =~ /C/g;
			my $G = () = $seq =~ /G/g;
			my $T = () = $seq =~ /T/g;
			my $GC = ($C + $G)/($A + $C + $G + $T);
			
			print "$name\t$len\t$GC\t$cov\t$blastHash{$name}\t$colors{$blastHash{$name}}\n";
		}
		
		chomp $_;
		$name = substr($_,1);
		
		if ($_ =~ /length\_(\d+)\_/){
			$len = $1 +$kmer - 1;
			if ($len >= $min_len){
				if ($_ =~ /cov\_([\d\.]+)/){
					$cov = $1;
					if ($cov >= $min_cov){
						$keep = 1;
						$seq = '';
					}else{
						$keep = 0;
						$seq = '';
					}
				}
			}else{
				$keep = 0;
				$seq = '';
			}
		}
	}else{
		$seq .= $_;
	}
}



sub open_file {
	use strict;
	use warnings;

    my($filename) = @_;
    my $fh;

    unless(open($fh, $filename)) {
        print "Cannot open file $filename\n";
        exit;
    }
    return $fh;
}
