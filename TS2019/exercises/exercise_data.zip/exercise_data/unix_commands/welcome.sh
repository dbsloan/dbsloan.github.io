#!/bin/bash

read -p "Pleas enter your name: " name

echo ""
echo "Hello, $name!  Welcome to Todos Santos!"
echo ""
